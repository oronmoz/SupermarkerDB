package com.example.supermarket.managers;

import com.example.supermarket.services.CustomerService;
import com.example.supermarket.services.ProductService;
import com.example.supermarket.services.SupermarketService;
import com.example.supermarket.services.impl.FileOperationsServiceImpl;
import javafx.stage.Stage;
import java.sql.SQLException;

public class SupermarketFileHandler {
    private SupermarketService supermarketService;
    private ProductService productService;
    private CustomerService customerService;
    private FileOperationsServiceImpl fileOperationsService;
    private Stage primaryStage;

    public SupermarketFileHandler(SupermarketService supermarketService, ProductService productService,
                                  CustomerService customerService, Stage primaryStage) {
        this.supermarketService = supermarketService;
        this.productService = productService;
        this.customerService = customerService;
        this.fileOperationsService = new FileOperationsServiceImpl(supermarketService, productService, customerService);
        this.primaryStage = primaryStage;
    }

    public void exportProductsToCSV() throws SQLException {
        fileOperationsService.exportToCSV(productService.getAllProducts(), "products.csv", primaryStage);
    }

    public void importProductsFromCSV() {
        fileOperationsService.importFromCSV("Product", primaryStage);
    }

    public void exportCustomersToCSV() throws SQLException {
        fileOperationsService.exportToCSV(customerService.getAll(), "customers.csv", primaryStage);
    }

    public void importCustomersFromCSV() {
        fileOperationsService.importFromCSV("Customer", primaryStage);
    }

    public void exportSupermarketToCSV() throws SQLException {
        fileOperationsService.exportToCSV(supermarketService.viewSupermarkets(), "supermarket.csv", primaryStage);
    }

    public void importSupermarketFromCSV() {
        fileOperationsService.importFromCSV("Supermarket", primaryStage);
    }
}
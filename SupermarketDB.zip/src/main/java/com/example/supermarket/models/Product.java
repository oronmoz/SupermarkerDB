package com.example.supermarket.models;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Float.parseFloat;
import static java.lang.String.valueOf;

public class Product {

    public enum ProductType {
        FRUIT_VEGETABLE("Fruit Vegetable"),
        FRIDGE("Fridge"),
        FROZEN("Frozen"),
        SHELF("Shelf");

        private final String displayName;

        ProductType(String displayName) {
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    private int id;
    private String name;
    private String barcode;
    private ProductType type;
    private float price;
    private int supplierId;

    // Default constructor
    public Product() {}

    public Product(String name, String barcode, ProductType type, float price, int supplierId) {
        this.name = name;
        this.barcode = barcode;
        this.type = type;
        this.price = price;
        this.supplierId = supplierId;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public ProductType getType() {
        return type;
    }

    public void setType(ProductType type) {
        this.type = type;
    }

    public String getPrice() {
        return valueOf(price);
    }

    public void setPrice(String price) {
        this.price = parseFloat(price);
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public String toString() {
        return String.format("%-20s %-10s\t%-20s %5.2f", name, barcode, type, price);
    }
}
package com.example.supermarket.models;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

public class ShoppingCart {
    private int id;
    private int supermarketId;
    private int customerId;
    private List<ShoppingItem> items;
    private LocalDateTime createdAt;
    private float totalPrice;

    // Default constructor
    public ShoppingCart() {}

    public ShoppingCart(int customerId, int supermarketId) {
        this.supermarketId = supermarketId;
        this.customerId = customerId;
        this.items = new ArrayList<>();
        this.createdAt = LocalDateTime.now();
        this.totalPrice = 0.0f;
    }

    // Existing getters and setters...


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void addItem(ShoppingItem item) {
        this.items.add(item);
        updateTotalPrice();
    }

    public void removeItem(ShoppingItem item) {
        this.items.remove(item);
        updateTotalPrice();
    }

    public int getItemCount() {
        return items.size();
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    private void updateTotalPrice() {
        this.totalPrice = (float) items.stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Shopping Cart:\n");
        for (ShoppingItem item : items) {
            sb.append(item).append("\n");
        }
        sb.append("Total: $").append(String.format("%.2f", getTotalPrice()));
        return sb.toString();
    }

    public List<ShoppingItem> getItems() {
        return new ArrayList<>(items); // Return a copy to prevent direct manipulation
    }

    public void setItems(List<ShoppingItem> items) {
        this.items = new ArrayList<>(items); // Create a new list to prevent direct manipulation
        updateTotalPrice();
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    public void setSupermarketId(int supermarketId) {
        this.supermarketId = supermarketId;
    }

    public int getCustomerId() {
        return this.customerId;
    }

    public int getSupermarketId() {
        return this.supermarketId;
    }

    public void clearItems() {
        this.items.clear();
        updateTotalPrice();
    }
}
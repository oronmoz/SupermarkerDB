package com.example.supermarket.services.impl;

import com.example.supermarket.database.dao.ProductDao;
import com.example.supermarket.database.dao.ProductSupermarketDao;
import com.example.supermarket.database.dao.SupermarketDao;
import com.example.supermarket.models.Product;
import com.example.supermarket.models.Supermarket;
import com.example.supermarket.services.ProductService;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class ProductServiceImpl implements ProductService {
    private ProductDao productDao;
    private ProductSupermarketDao productSupermarketDao;
    private SupermarketDao supermarketDao;

    public ProductServiceImpl(ProductDao productDao, ProductSupermarketDao productSupermarketDao, SupermarketDao supermarketDao) {
        this.productDao = productDao;
        this.productSupermarketDao = productSupermarketDao;
        this.supermarketDao = supermarketDao;
    }

    @Override
    public List<Product> getAllProducts() throws SQLException {
        return productDao.getAll();
    }

    @Override
    public Product saveProduct(Product product) throws SQLException {
        return productDao.create(product);
    }

    @Override
    public Product getProductByBarcode(String barcode) throws SQLException {
        return productDao.getByBarcode(barcode);
    }

    @Override
    public List<Product> getProductsByType(Product.ProductType type) throws SQLException {
        return productDao.getByType(type);
    }

    @Override
    public void updateProduct(Product product) throws SQLException {
        productDao.update(product);
    }

    @Override
    public int getNumOfProducts() throws SQLException {
        return productDao.getAll().size();
    }

    @Override
    public void addProductToSupermarket(int productId, int supermarketId, int initialStock) throws SQLException {
        productSupermarketDao.addProductToSupermarket(productId, supermarketId, initialStock);
    }

    @Override
    public void removeProductFromSupermarket(int productId, int supermarketId) throws SQLException {
        productSupermarketDao.removeProductFromSupermarket(productId, supermarketId);
    }

    @Override
    public void updateProductStock(int productId, int supermarketId, int newStock) throws SQLException {
        productSupermarketDao.updateStock(productId, supermarketId, newStock);
    }

    @Override
    public List<Supermarket> getSupermarketsByProduct(int productId) throws SQLException {
        List<Integer> supermarketIds = productSupermarketDao.getSupermarketIdsForProduct(productId);
        return supermarketIds.stream()
                .map(id -> {
                    try {
                        return supermarketDao.getById(id);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());
    }

    @Override
    public List<Product> getProductsBySupermarket(int supermarketId) throws SQLException {
        return productDao.getBySupermarket(supermarketId);
    }

    @Override
    public int getTotalCountForProduct(int productId) throws SQLException {
        List<Integer> supermarketIds = productSupermarketDao.getSupermarketIdsForProduct(productId);
        int totalCount = 0;
        for (int supermarketId : supermarketIds) {
            totalCount += productSupermarketDao.getStock(productId, supermarketId);
        }
        return totalCount;
    }
}
package com.example.supermarket.services.impl;

import com.example.supermarket.database.dao.CustomerDao;
import com.example.supermarket.database.dao.SupermarketDao;
import com.example.supermarket.database.dao.ProductSupermarketDao;
import com.example.supermarket.models.Supermarket;
import com.example.supermarket.models.Product;
import com.example.supermarket.models.Customer;
import com.example.supermarket.services.SupermarketService;
import com.example.supermarket.services.AddressService;

import java.sql.SQLException;
import java.util.List;

public class SupermarketServiceImpl implements SupermarketService {
    private SupermarketDao supermarketDao;
    private ProductSupermarketDao productSupermarketDao;
    private AddressService addressService;
    private CustomerDao customerDao;

    public SupermarketServiceImpl(SupermarketDao supermarketDao, ProductSupermarketDao productSupermarketDao,
                                  AddressService addressService, CustomerDao customerDao) {
        this.supermarketDao = supermarketDao;
        this.productSupermarketDao = productSupermarketDao;
        this.addressService = addressService;
        this.customerDao = customerDao;
    }

    @Override
    public List<Supermarket> getAll() throws SQLException {
        return List.of();
    }

    @Override
    public Supermarket addSupermarket(Supermarket supermarket) throws SQLException {
        addressService.createAddress(supermarket.getLocation());
        return supermarketDao.create(supermarket);
    }

    @Override
    public List<Supermarket> viewSupermarkets() throws SQLException {
        return supermarketDao.getAll();
    }

    @Override
    public List<Supermarket> searchSupermarket(String name) throws SQLException {
        return supermarketDao.getByName(name);
    }

    @Override
    public void updateSupermarket(Supermarket supermarket) throws SQLException {
        supermarketDao.update(supermarket);
        addressService.updateAddress(supermarket.getLocation());
    }

    @Override
    public void deleteSupermarket(int id) throws SQLException {
        Supermarket supermarket = getSupermarketById(id);
        if (supermarket != null) {
            addressService.deleteAddress(supermarket.getLocation().getId());
            supermarketDao.delete(id);
        }
    }

    @Override
    public Supermarket getSupermarketById(int id) throws SQLException {
        return supermarketDao.getById(id);
    }

    @Override
    public void addProductToSupermarket(int productId, int supermarketId, int initialStock) throws SQLException {
        productSupermarketDao.addProductToSupermarket(productId, supermarketId, initialStock);
    }

    @Override
    public void removeProductFromSupermarket(int productId, int supermarketId) throws SQLException {
        productSupermarketDao.removeProductFromSupermarket(productId, supermarketId);
    }

    @Override
    public List<Supermarket> getSupermarketsByProduct(int productId) throws SQLException {
        List<Integer> supermarketIds = productSupermarketDao.getSupermarketIdsForProduct(productId);
        return getSupermarketsByIds(supermarketIds);
    }

    @Override
    public List<Product> getProductsBySupermarket(int supermarketId) throws SQLException {
        return List.of();
    }

//    TODO: @Override
//    public List<Product> getProductsBySupermarket(int supermarketId) throws SQLException {
//        List<Integer> productsIds = productSupermarketDao.getProductIdsForSupermarket(supermarketId);
//        return getProductsByIds(productsIds);
//    }

    @Override
    public List<Customer> getCustomersBySupermarket(int supermarketId) throws SQLException {
        return supermarketDao.getCustomersBySupermarket(supermarketId);
    }

    @Override
    public void addCustomerToSupermarket(int customerId, int supermarketId) throws SQLException {
        supermarketDao.addCustomerToSupermarket(customerId, supermarketId);
    }

    @Override
    public void removeCustomerFromSupermarket(int customerId, int supermarketId) throws SQLException {
        supermarketDao.removeCustomerFromSupermarket(customerId, supermarketId);
    }

    @Override
    public List<Supermarket> getAllSupermarkets() throws SQLException {
        return supermarketDao.getAll();
    }

    @Override
    public List<Supermarket> getSupermarketsByIds(List<Integer> ids) throws SQLException {
        return supermarketDao.getByIds(ids);
    }

    @Override
    public List<Supermarket> getProductsByIds(List<Integer> ids) throws SQLException {
        return List.of();
    }

    @Override
    public Customer saveCustomer(Customer customer) throws SQLException {
        return customerDao.create(customer);
    }

    @Override
    public List<Customer> getAllCustomers() throws SQLException {
        return customerDao.getAll();
    }

    @Override
    public int getCustomerTotalShopTimes(int customerId) throws SQLException {
        return 0;
    }

    @Override
    public float getCustomerTotalSpend(int customerId) throws SQLException {
        return 0;
    }

//    TODO: @Override
//    public int getCustomerTotalShopTimes(int customerId) throws SQLException {
//        return customerDao.getTotalShopTimes(customerId);
//    }
//
//    @Override
//    public float getCustomerTotalSpend(int customerId) throws SQLException {
//        return customerDao.getTotalSpend(customerId);
//    }

    @Override
    public Customer getCustomerByName(String name) throws SQLException {
        return customerDao.getByName(name);
    }
}
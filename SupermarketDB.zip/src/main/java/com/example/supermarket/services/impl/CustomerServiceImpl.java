package com.example.supermarket.services.impl;

import com.example.supermarket.database.dao.CustomerDao;
import com.example.supermarket.database.dao.SupermarketCustomerDao;
import com.example.supermarket.database.dao.SupermarketDao;
import com.example.supermarket.models.Customer;
import com.example.supermarket.models.Supermarket;
import com.example.supermarket.models.CustomerSupermarket;
import com.example.supermarket.services.CustomerService;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class CustomerServiceImpl implements CustomerService {
    private CustomerDao customerDao;
    private SupermarketCustomerDao supermarketCustomerDao;
    private SupermarketDao supermarketDao;

    public CustomerServiceImpl(CustomerDao customerDao, SupermarketCustomerDao supermarketCustomerDao, SupermarketDao supermarketDao) {
        this.customerDao = customerDao;
        this.supermarketCustomerDao = supermarketCustomerDao;
        this.supermarketDao = supermarketDao;
    }

    @Override
    public List<Customer> getAll() throws SQLException {
        return customerDao.getAll();
    }

    @Override
    public Customer save(Customer customer) throws SQLException {
        return customerDao.create(customer);
    }

    @Override
    public Customer getByName(String name) throws SQLException {
        return customerDao.getByName(name);
    }

    @Override
    public List<Customer> getSorted(SortOption sortOption) throws SQLException {
        List<Customer> customers = getAll();
        switch (sortOption) {
            case NAME:
                customers.sort((c1, c2) -> c1.getName().compareTo(c2.getName()));
                break;
            case SHOP_TIMES:
                customers.sort((c1, c2) -> {
                    try {
                        return Integer.compare(getCustomerShopTimes(c2.getId()), getCustomerShopTimes(c1.getId()));
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                });
                break;
            case TOTAL_SPEND:
                customers.sort((c1, c2) -> {
                    try {
                        return Float.compare(getTotalSpend(c2.getId()), getTotalSpend(c1.getId()));
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                });
                break;
        }
        return customers;
    }

    @Override
    public List<Customer> getBySupermarket(int supermarketId) throws SQLException {
        return customerDao.getCustomersBySupermarket(supermarketId);
    }

    @Override
    public void addToSupermarket(int customerId, int supermarketId) throws SQLException {
        CustomerSupermarket customerSupermarket = new CustomerSupermarket();
        customerSupermarket.setCustomerId(customerId);
        customerSupermarket.setSupermarketId(supermarketId);
        customerSupermarket.setShopTimes(0);
        customerSupermarket.setTotalSpend(0);
        supermarketCustomerDao.create(customerSupermarket);
    }

    @Override
    public void removeFromSupermarket(int customerId, int supermarketId) throws SQLException {
        supermarketCustomerDao.delete(customerId, supermarketId);
    }

    @Override
    public List<Supermarket> getSupermarketsByCustomer(int customerId) throws SQLException {
        List<CustomerSupermarket> relationships = supermarketCustomerDao.getAllByCustomer(customerId);
        return relationships.stream()
                .map(cs -> {
                    try {
                        return supermarketDao.getById(cs.getSupermarketId());
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.toList());
    }

    @Override
    public float getTotalSpend(int customerId) throws SQLException {
        List<CustomerSupermarket> relationships = supermarketCustomerDao.getAllByCustomer(customerId);
        return (float) relationships.stream().mapToDouble(CustomerSupermarket::getTotalSpend).sum();
    }

    @Override
    public int getCustomerShopTimes(int customerId) throws SQLException {
        List<CustomerSupermarket> relationships = supermarketCustomerDao.getAllByCustomer(customerId);
        return relationships.stream().mapToInt(CustomerSupermarket::getShopTimes).sum();
    }

    @Override
    public void update(Customer customer) throws SQLException {
        customerDao.update(customer);
    }

    @Override
    public void updateAfterPurchase(int customerId, float purchaseAmount) throws SQLException {
        List<CustomerSupermarket> relationships = supermarketCustomerDao.getAllByCustomer(customerId);
        if (!relationships.isEmpty()) {
            CustomerSupermarket relationship = relationships.get(0); // Assuming the customer is associated with one supermarket
            relationship.setShopTimes(relationship.getShopTimes() + 1);
            relationship.setTotalSpend(relationship.getTotalSpend() + purchaseAmount);
            supermarketCustomerDao.update(relationship);
        } else {
            throw new SQLException("Customer is not associated with any supermarket");
        }
    }
}
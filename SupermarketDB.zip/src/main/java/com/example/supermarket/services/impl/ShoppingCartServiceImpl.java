package com.example.supermarket.services.impl;

import com.example.supermarket.database.dao.ShoppingCartDao;
import com.example.supermarket.models.ShoppingCart;
import com.example.supermarket.models.ShoppingItem;
import com.example.supermarket.services.ShoppingCartService;

import java.sql.SQLException;
import java.util.List;

public class ShoppingCartServiceImpl implements ShoppingCartService {
    private ShoppingCartDao shoppingCartDao;

    public ShoppingCartServiceImpl(ShoppingCartDao shoppingCartDao) {
        this.shoppingCartDao = shoppingCartDao;
    }

    @Override
    public ShoppingCart createShoppingCart(int customerId, int supermarketId) throws SQLException {
        return shoppingCartDao.create(customerId, supermarketId);
    }

    @Override
    public ShoppingCart getCartByCustomerAndSupermarket(int customerId, int supermarketId) {
        try {
            return shoppingCartDao.getCartByCustomerAndSupermarket(customerId, supermarketId);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<ShoppingCart> getCartsByCustomerId(int customerId) throws SQLException {
        return shoppingCartDao.getCartsByCustomerId(customerId);
    }

    @Override
    public void addItemToCart(ShoppingCart cart, ShoppingItem item) throws SQLException {
        shoppingCartDao.addItem(cart.getId(), item);
    }


    @Override
    public void removeItemFromCart(ShoppingCart cart, ShoppingItem item) throws SQLException {
        shoppingCartDao.removeItem(cart.getId(), item.getId());
    }

    @Override
    public void checkout(int customerId, int supermarketId) throws SQLException {
        ShoppingCart cart = getCartByCustomerAndSupermarket(customerId, supermarketId);
        if (cart != null) {
            //TODO: Implement checkout logic here
            // This might involve creating a new Purchase record, updating inventory, etc.
            deleteCart(cart.getId());
        }
    }

    @Override
    public void deleteCart(int cartId) throws SQLException {
        shoppingCartDao.deleteCart(cartId);
    }

    @Override
    public float calculateCartTotal(ShoppingCart cart) throws SQLException {
        return shoppingCartDao.getTotalPrice(cart.getId());
    }

    @Override
    public List<ShoppingItem> getCartItems(int cartId) throws SQLException {
        return shoppingCartDao.getItemsByCartId(cartId);
    }

    @Override
    public List<ShoppingCart> getAll() throws SQLException {
        return shoppingCartDao.getAll();
    }

    @Override
    public List<ShoppingCart> getShoppingCartsBySupermarketId(int supermarketId) throws SQLException {
        return shoppingCartDao.getCartsByCustomerId(supermarketId);
    }

    @Override
    public void updateItemQuantity(ShoppingCart cart, ShoppingItem item, int newQuantity) throws SQLException {
        shoppingCartDao.updateItemQuantity(cart.getId(), item.getId(), newQuantity);
    }

    @Override
    public void updateCartItems(int cartId, List<ShoppingItem> items) throws SQLException {
        shoppingCartDao.updateItems(cartId, items);
    }
}
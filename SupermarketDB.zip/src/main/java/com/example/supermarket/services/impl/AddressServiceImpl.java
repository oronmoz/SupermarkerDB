package com.example.supermarket.services.impl;

import com.example.supermarket.database.dao.AddressDao;
import com.example.supermarket.models.Address;
import com.example.supermarket.services.AddressService;

import java.sql.SQLException;
import java.util.List;

public class AddressServiceImpl implements AddressService {
    private AddressDao addressDao;

    public AddressServiceImpl(AddressDao addressDao) {
        this.addressDao = addressDao;
    }

    @Override
    public Address createAddress(Address address) throws SQLException {
        return addressDao.create(address);
    }

    @Override
    public Address getAddressById(int id) throws SQLException {
        return addressDao.getById(id);
    }

    @Override
    public List<Address> getAddressesByCustomerId(int customerId) throws SQLException {
        return addressDao.getByCustomerId(customerId);
    }

    @Override
    public Address getAddressBySupermarketId(int supermarketId) throws SQLException {
        return addressDao.getBySupermarketId(supermarketId);
    }

    @Override
    public void updateAddress(Address address) throws SQLException {
        addressDao.update(address);
    }

    @Override
    public void deleteAddress(int id) throws SQLException {
        addressDao.delete(id);
    }
}
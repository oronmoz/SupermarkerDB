package com.example.supermarket.services;

import com.example.supermarket.models.ShoppingCart;
import com.example.supermarket.models.ShoppingItem;

import java.sql.SQLException;
import java.util.List;

public interface ShoppingCartService {
    ShoppingCart createShoppingCart(int customerId, int supermarketId) throws SQLException;
    ShoppingCart getCartByCustomerAndSupermarket(int customerId, int supermarketId);
    List<ShoppingCart> getCartsByCustomerId(int customerId) throws SQLException;
    List<ShoppingItem> getCartItems(int cartId) throws SQLException;
    List<ShoppingCart> getAll() throws SQLException;
    List<ShoppingCart> getShoppingCartsBySupermarketId(int supermarketId) throws SQLException;
    void addItemToCart(ShoppingCart cart, ShoppingItem item) throws SQLException;

    void removeItemFromCart(ShoppingCart cart, ShoppingItem item) throws SQLException;
    void checkout(int customerId, int supermarketId) throws SQLException;
    void deleteCart(int cartId) throws SQLException;
    float calculateCartTotal(ShoppingCart cart) throws SQLException;
    void updateItemQuantity(ShoppingCart cart, ShoppingItem item, int newQuantity) throws SQLException;
    void updateCartItems(int cartId, List<ShoppingItem> items) throws SQLException;
}
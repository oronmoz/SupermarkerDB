package com.example.supermarket.services;

import com.example.supermarket.models.Supermarket;
import com.example.supermarket.models.Product;
import com.example.supermarket.models.Customer;

import java.sql.SQLException;
import java.util.List;

public interface SupermarketService {
    List<Supermarket> getAll() throws SQLException;
    Supermarket addSupermarket(Supermarket supermarket) throws SQLException;
    List<Supermarket> viewSupermarkets() throws SQLException;

    List<Supermarket> searchSupermarket(String name) throws SQLException;

    void updateSupermarket(Supermarket supermarket) throws SQLException;
    void deleteSupermarket(int id) throws SQLException;
    Supermarket getSupermarketById(int id) throws SQLException;

    void addProductToSupermarket(int productId, int supermarketId, int initialStock) throws SQLException;

    void removeProductFromSupermarket(int productId, int supermarketId) throws SQLException;

    List<Supermarket> getSupermarketsByProduct(int productId) throws SQLException;
    List<Product> getProductsBySupermarket(int supermarketId) throws SQLException;
    List<Customer> getCustomersBySupermarket(int supermarketId) throws SQLException;

    void addCustomerToSupermarket(int customerId, int supermarketId) throws SQLException;

    void removeCustomerFromSupermarket(int customerId, int supermarketId) throws SQLException;

    List<Supermarket> getAllSupermarkets() throws SQLException;
    List<Supermarket> getSupermarketsByIds(List<Integer> ids) throws SQLException;
    Customer saveCustomer(Customer customer) throws SQLException;
    List<Customer> getAllCustomers() throws SQLException;
    int getCustomerTotalShopTimes(int customerId) throws SQLException;
    float getCustomerTotalSpend(int customerId) throws SQLException;
    Customer getCustomerByName(String name) throws SQLException;
    List<Supermarket> getProductsByIds(List<Integer> ids) throws SQLException;

    //void addCustomerToSupermarket(int customerId, int supermarketId) throws SQLException;
    //void removeCustomerFromSupermarket(int customerId, int supermarketId) throws SQLException;
    //void addProductToSupermarket(int productId, int supermarketId, int initialStock) throws SQLException;
    //void removeProductFromSupermarket(int productId, int supermarketId) throws SQLException;
    //List<Supermarket> searchSupermarket(String name) throws SQLException;
}

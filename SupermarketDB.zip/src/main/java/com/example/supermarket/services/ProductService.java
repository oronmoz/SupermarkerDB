package com.example.supermarket.services;

import com.example.supermarket.models.Product;
import com.example.supermarket.models.Supermarket;

import java.sql.SQLException;
import java.util.List;

public interface ProductService {
    List<Product> getAllProducts() throws SQLException;
    Product saveProduct(Product product) throws SQLException;
    Product getProductByBarcode(String barcode) throws SQLException;
    List<Product> getProductsByType(Product.ProductType type) throws SQLException;
    void updateProduct(Product product) throws SQLException;
    int getNumOfProducts() throws SQLException;
    void addProductToSupermarket(int productId, int supermarketId, int initialStock) throws SQLException;
    void removeProductFromSupermarket(int productId, int supermarketId) throws SQLException;
    void updateProductStock(int productId, int supermarketId, int newStock) throws SQLException;
    List<Supermarket> getSupermarketsByProduct(int productId) throws SQLException;
    List<Product> getProductsBySupermarket(int supermarketId) throws SQLException;
    int getTotalCountForProduct(int productId) throws SQLException;
}
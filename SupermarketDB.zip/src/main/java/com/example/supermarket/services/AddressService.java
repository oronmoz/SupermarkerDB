package com.example.supermarket.services;

import com.example.supermarket.models.Address;

import java.sql.SQLException;
import java.util.List;

public interface AddressService {
    Address createAddress(Address address) throws SQLException;
    Address getAddressById(int id) throws SQLException;
    List<Address> getAddressesByCustomerId(int customerId) throws SQLException;
    Address getAddressBySupermarketId(int supermarketId) throws SQLException;
    void updateAddress(Address address) throws SQLException;
    void deleteAddress(int id) throws SQLException;
}
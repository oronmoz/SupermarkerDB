package com.example.supermarket.components;

import javafx.scene.control.TreeView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeCell;

import java.util.function.Consumer;

public class ReportSelectionTreeView extends TreeView<String> {

    public ReportSelectionTreeView() {
        // Default constructor
    }

    public ReportSelectionTreeView(Consumer<String> onReportSelected) {
        TreeItem<String> root = new TreeItem<>("Reports");
        root.setExpanded(true);

        TreeItem<String> salesReports = new TreeItem<>("Sales Reports");
        salesReports.getChildren().addAll(
                new TreeItem<>("Daily Sales"),
                new TreeItem<>("Monthly Sales"),
                new TreeItem<>("Annual Sales")
        );

        TreeItem<String> inventoryReports = new TreeItem<>("Inventory Reports");
        inventoryReports.getChildren().addAll(
                new TreeItem<>("Low Stock Alert"),
                new TreeItem<>("Product Performance")
        );

        TreeItem<String> customerReports = new TreeItem<>("Customer Reports");
        customerReports.getChildren().addAll(
                new TreeItem<>("Top Customers"),
                new TreeItem<>("Customer Shopping Patterns")
        );

        TreeItem<String> supplierReports = new TreeItem<>("Supplier Reports");
        TreeItem<String> supermarketReports = new TreeItem<>("Supermarket Performance");

        root.getChildren().addAll(salesReports, inventoryReports, customerReports, supplierReports, supermarketReports);

        this.setRoot(root);
        this.setShowRoot(false);

        this.setCellFactory(tv -> {
            TreeCell<String> cell = new TreeCell<String>() {
                @Override
                protected void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty ? null : item);
                }
            };

            cell.setOnMouseClicked(event -> {
                if (!cell.isEmpty() && cell.getTreeItem().isLeaf()) {
                    onReportSelected.accept(cell.getItem());
                }
            });

            return cell;
        });
    }
}
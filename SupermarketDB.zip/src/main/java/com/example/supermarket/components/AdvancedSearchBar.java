package com.example.supermarket.components;

import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.control.ComboBox;
import javafx.collections.FXCollections;

import java.util.function.Consumer;

public class AdvancedSearchBar extends HBox {
    private TextField searchField;
    private ComboBox<String> searchCriteria;
    private Button searchButton;

    public AdvancedSearchBar() {
        // Default constructor for FXML
    }

    public AdvancedSearchBar(String[] criteria, Consumer<String> onSearch) {
        initialize(criteria, onSearch);
    }

    public void initialize(String[] criteria, Consumer<String> onSearch) {
        // Clear existing children if any
        this.getChildren().clear();

        searchField = new TextField();
        searchField.setPromptText("Enter search term");

        searchCriteria = new ComboBox<>(FXCollections.observableArrayList(criteria));
        searchCriteria.setPromptText("Select criteria");

        searchButton = new Button("Search");
        searchButton.setOnAction(e -> {
            String searchTerm = searchField.getText();
            String selectedCriteria = searchCriteria.getValue();
            if (selectedCriteria != null && !searchTerm.isEmpty()) {
                onSearch.accept(selectedCriteria + ":" + searchTerm);
            }
        });

        this.setSpacing(10);
        this.getChildren().addAll(searchField, searchCriteria, searchButton);
    }

    public String getSearchTerm() {
        return searchField.getText();
    }

    public String getSelectedCriteria() {
        return searchCriteria.getValue();
    }
}
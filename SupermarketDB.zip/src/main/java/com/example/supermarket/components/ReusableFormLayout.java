package com.example.supermarket.components;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.util.HashMap;
import java.util.Map;

public class ReusableFormLayout extends GridPane {
    private Map<String, TextField> fields;

    public ReusableFormLayout() {
        this.setAlignment(Pos.CENTER);
        this.setHgap(10);
        this.setVgap(10);
        this.setPadding(new Insets(25, 25, 25, 25));

        fields = new HashMap<>();
    }

    public void addField(String labelText, String promptText) {
        int rowIndex = this.getRowCount();

        Label label = new Label(labelText);
        TextField textField = new TextField();
        textField.setPromptText(promptText);

        this.add(label, 0, rowIndex);
        this.add(textField, 1, rowIndex);

        fields.put(labelText, textField);
    }

    public String getFieldValue(String fieldName) {
        TextField field = fields.get(fieldName);
        return field != null ? field.getText() : null;
    }

    public void setFieldValue(String fieldName, String value) {
        TextField field = fields.get(fieldName);
        if (field != null) {
            field.setText(value);
        }
    }

    public void clearFields() {
        fields.values().forEach(TextField::clear);
    }
}
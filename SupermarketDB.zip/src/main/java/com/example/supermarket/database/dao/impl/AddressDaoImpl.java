package com.example.supermarket.database.dao.impl;

import com.example.supermarket.database.DatabaseManager;
import com.example.supermarket.database.queriesmanager.AddressQueries;
import com.example.supermarket.models.Address;
import com.example.supermarket.database.dao.AddressDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AddressDaoImpl implements AddressDao {
    private DatabaseManager dbManager;

    public AddressDaoImpl() {
        this.dbManager = DatabaseManager.getInstance();
    }

    @Override
    public Address create(Address address) throws SQLException {
        ResultSet rs = dbManager.executeQuery(AddressQueries.INSERT_ADDRESS,
                address.getNum(), address.getStreet(), address.getCity());
        if (rs.next()) {
            address.setId(rs.getInt(1));
        }
        return address;
    }

    @Override
    public Address getById(int id) throws SQLException {
        ResultSet rs = dbManager.executeQuery(AddressQueries.SELECT_ADDRESS_BY_ID, id);
        if (rs.next()) {
            return extractAddressFromResultSet(rs);
        }
        return null;
    }

    @Override
    public List<Address> getByCustomerId(int customerId) throws SQLException {
        List<Address> addresses = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(AddressQueries.SELECT_ADDRESS_BY_CUSTOMER_ID, customerId);
        while (rs.next()) {
            addresses.add(extractAddressFromResultSet(rs));
        }
        return addresses;
    }

    @Override
    public Address getBySupermarketId(int supermarketId) throws SQLException {
        ResultSet rs = dbManager.executeQuery(AddressQueries.SELECT_ADDRESS_BY_SUPERMARKET_ID, supermarketId);
        if (rs.next()) {
            return extractAddressFromResultSet(rs);
        }
        return null;
    }

    @Override
    public void update(Address address) throws SQLException {
        dbManager.executeUpdate(AddressQueries.UPDATE_ADDRESS,
                address.getNum(), address.getStreet(), address.getCity(), address.getId());
    }

    @Override
    public void delete(int id) throws SQLException {
        dbManager.executeUpdate(AddressQueries.DELETE_ADDRESS, id);
    }

    @Override
    public void deleteByCustomerId(int customerId) throws SQLException {
        dbManager.executeUpdate(AddressQueries.DELETE_ADDRESSES_BY_CUSTOMER_ID, customerId);
    }

    @Override
    public void deleteBySupermarketId(int supermarketId) throws SQLException {
        dbManager.executeUpdate(AddressQueries.DELETE_ADDRESSES_BY_SUPERMARKET_ID, supermarketId);
    }

    private Address extractAddressFromResultSet(ResultSet rs) throws SQLException {
        Address address = new Address();
        address.setId(rs.getInt("id"));
        address.setNum(rs.getInt("num"));
        address.setStreet(rs.getString("street"));
        address.setCity(rs.getString("city"));
        return address;
    }
}
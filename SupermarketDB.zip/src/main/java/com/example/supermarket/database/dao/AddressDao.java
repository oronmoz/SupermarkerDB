package com.example.supermarket.database.dao;

import com.example.supermarket.models.Address;
import java.sql.SQLException;
import java.util.List;

public interface AddressDao {
    Address create(Address address) throws SQLException;
    Address getById(int id) throws SQLException;
    List<Address> getByCustomerId(int customerId) throws SQLException;
    void update(Address address) throws SQLException;
    void delete(int id) throws SQLException;
    void deleteByCustomerId(int customerId) throws SQLException;
    Address getBySupermarketId(int supermarketId) throws SQLException;
    void deleteBySupermarketId(int supermarketId) throws SQLException;

    }
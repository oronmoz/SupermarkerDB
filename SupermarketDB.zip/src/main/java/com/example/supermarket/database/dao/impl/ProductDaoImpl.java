package com.example.supermarket.database.dao.impl;

import com.example.supermarket.database.DatabaseManager;
import com.example.supermarket.database.queriesmanager.ProductQueries;
import com.example.supermarket.models.Product;
import com.example.supermarket.database.dao.ProductDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl implements ProductDao {
    private DatabaseManager dbManager;

    public ProductDaoImpl() {
        this.dbManager = DatabaseManager.getInstance();
    }

    @Override
    public Product create(Product product) throws SQLException {
        ResultSet rs = dbManager.executeQuery(ProductQueries.INSERT_PRODUCT,
                product.getName(), product.getBarcode(), product.getType().toString(),
                product.getPrice(), product.getSupplierId());
        if (rs.next()) {
            product.setId(rs.getInt(1));
        }
        return product;
    }

    @Override
    public Product getByBarcode(String barcode) throws SQLException {
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_PRODUCT_BY_BARCODE, barcode);
        if (rs.next()) {
            return extractProductFromResultSet(rs);
        }
        return null;
    }

    @Override
    public Product getById(int id) throws SQLException {
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_PRODUCT_BY_ID, id);
        if (rs.next()) {
            return extractProductFromResultSet(rs);
        }
        return null;
    }

    @Override
    public List<Product> getAll() throws SQLException {
        List<Product> products = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_ALL_PRODUCTS);
        while (rs.next()) {
            products.add(extractProductFromResultSet(rs));
        }
        return products;
    }

    @Override
    public void update(Product product) throws SQLException {
        dbManager.executeUpdate(ProductQueries.UPDATE_PRODUCT,
                product.getName(), product.getType().toString(), product.getPrice(),
                product.getSupplierId(), product.getBarcode());
    }

    @Override
    public void delete(String barcode) throws SQLException {
        dbManager.executeUpdate(ProductQueries.DELETE_PRODUCT, barcode);
    }

    @Override
    public List<Product> getByType(Product.ProductType type) throws SQLException {
        List<Product> products = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_PRODUCTS_BY_TYPE, type.toString());
        while (rs.next()) {
            products.add(extractProductFromResultSet(rs));
        }
        return products;
    }

    @Override
    public List<Product> getBySupermarket(int supermarketId) throws SQLException {
        List<Product> products = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_PRODUCTS_BY_SUPERMARKET, supermarketId);
        while (rs.next()) {
            products.add(extractProductFromResultSet(rs));
        }
        return products;
    }

    @Override
    public List<Product> getBySupplier(int supplierId) throws SQLException {
        List<Product> products = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(ProductQueries.SELECT_PRODUCTS_BY_SUPPLIER, supplierId);
        while (rs.next()) {
            products.add(extractProductFromResultSet(rs));
        }
        return products;
    }

    private Product extractProductFromResultSet(ResultSet rs) throws SQLException {
        Product product = new Product();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setBarcode(rs.getString("barcode"));
        product.setType(Product.ProductType.valueOf(rs.getString("type")));
        product.setPrice(rs.getString("price"));
        product.setSupplierId(rs.getInt("supplier_id"));
        return product;
    }
}
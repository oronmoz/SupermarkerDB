package com.example.supermarket.database.queriesmanager;

public class CustomerQueries {
    public static final String CREATE_CUSTOMER_TABLE =
            "CREATE TABLE IF NOT EXISTS customers (" +
                    "id SERIAL PRIMARY KEY, " +
                    "name VARCHAR(255) UNIQUE NOT NULL)";

    public static final String INSERT_CUSTOMER =
            "INSERT INTO customers (name) VALUES (?)";

    public static final String SELECT_ALL_CUSTOMERS =
            "SELECT * FROM customers";

    public static final String SELECT_CUSTOMER_BY_NAME =
            "SELECT * FROM customers WHERE name = ?";

    public static final String UPDATE_CUSTOMER =
            "UPDATE customers SET name = ? WHERE id = ?";

    public static final String DELETE_CUSTOMER =
            "DELETE FROM customers WHERE id = ?";

    public static final String SELECT_CUSTOMERS_BY_SUPERMARKET =
            "SELECT c.* FROM customers c " +
                    "JOIN customer_supermarket cs ON c.id = cs.customer_id " +
                    "WHERE cs.supermarket_id = ?";

    public static final String SELECT_SORTED_CUSTOMERS =
            "SELECT * FROM customers ORDER BY %s %s";
}
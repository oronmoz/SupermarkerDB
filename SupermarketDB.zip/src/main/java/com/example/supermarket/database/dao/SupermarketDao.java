package com.example.supermarket.database.dao;

import com.example.supermarket.models.Customer;
import com.example.supermarket.models.Supermarket;
import java.sql.SQLException;
import java.util.List;

public interface SupermarketDao {
    Supermarket create(Supermarket supermarket) throws SQLException;
    Supermarket getById(int id) throws SQLException;
    List<Supermarket> getAll() throws SQLException;
    void update(Supermarket supermarket) throws SQLException;
    void delete(int id) throws SQLException;
    List<Supermarket> getByName(String name) throws SQLException;
    List<Supermarket> getSorted(String sortBy, String sortOrder) throws SQLException;
    List<Customer> getCustomersBySupermarket(int supermarketId) throws SQLException;
    void addCustomerToSupermarket(int customerId, int supermarketId) throws SQLException;
    void removeCustomerFromSupermarket(int customerId, int supermarketId) throws SQLException;
    List<Supermarket> getByProduct(int productId) throws SQLException;
    List<Supermarket> getByIds(List<Integer> ids) throws SQLException; // New method
}
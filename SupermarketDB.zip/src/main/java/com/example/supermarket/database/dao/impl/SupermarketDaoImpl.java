package com.example.supermarket.database.dao.impl;

import com.example.supermarket.database.DatabaseManager;
import com.example.supermarket.database.dao.SupermarketDao;
import com.example.supermarket.database.queriesmanager.AddressQueries;
import com.example.supermarket.database.queriesmanager.SupermarketQueries;
import com.example.supermarket.models.Customer;
import com.example.supermarket.models.Supermarket;
import com.example.supermarket.models.Address;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SupermarketDaoImpl implements SupermarketDao {
    private DatabaseManager dbManager;

    public SupermarketDaoImpl() {
        this.dbManager = DatabaseManager.getInstance();
    }

    @Override
    public Supermarket create(Supermarket supermarket) throws SQLException {
        ResultSet rs = dbManager.executeQuery(SupermarketQueries.INSERT_SUPERMARKET,
                supermarket.getName(),
                supermarket.getLocation().getId());
        if (rs.next()) {
            supermarket.setId(rs.getInt(1));
        }
        return supermarket;
    }

    @Override
    public Supermarket getById(int id) throws SQLException {
        ResultSet rs = dbManager.executeQuery(SupermarketQueries.GET_SUPERMARKET_BY_ID, id);
        if (rs.next()) {
            return extractSupermarketFromResultSet(rs);
        }
        return null;
    }

    @Override
    public List<Supermarket> getAll() throws SQLException {
        List<Supermarket> supermarkets = new ArrayList<>();
        ResultSet rs = dbManager.executeQuery(SupermarketQueries.GET_ALL_SUPERMARKETS);
        while (rs.next()) {
            supermarkets.add(extractSupermarketFromResultSet(rs));
        }
        return supermarkets;
    }

    @Override
    public void update(Supermarket supermarket) throws SQLException {
        dbManager.executeUpdate(SupermarketQueries.UPDATE_SUPERMARKET,
                supermarket.getName(),
                supermarket.getLocation().getId(),
                supermarket.getId());
    }

    @Override
    public void delete(int id) throws SQLException {
        dbManager.executeUpdate(SupermarketQueries.DELETE_SUPERMARKET, id);
    }

    @Override
    public List<Supermarket> getByName(String name) throws SQLException {
        ResultSet rs = dbManager.executeQuery(SupermarketQueries.GET_SUPERMARKET_BY_NAME, name);
        List<Supermarket> supermarkets = new ArrayList<>();
        while (rs.next()) {
            supermarkets.add(extractSupermarketFromResultSet(rs));
        }
        return supermarkets;
    }

    @Override
    public List<Supermarket> getByProduct(int productId) throws SQLException {
        ResultSet rs = dbManager.executeQuery(SupermarketQueries.GET_SUPERMARKETS_BY_PRODUCT, productId);
        List<Supermarket> supermarkets = new ArrayList<>();
        while (rs.next()) {
            supermarkets.add(extractSupermarketFromResultSet(rs));
        }
        return supermarkets;
    }

    private Supermarket extractSupermarketFromResultSet(ResultSet rs) throws SQLException {
        Supermarket supermarket = new Supermarket();
        supermarket.setId(rs.getInt("id"));
        supermarket.setName(rs.getString("name"));

        int locationId = rs.getInt("location_id");
        Address address = new Address();

        ResultSet rsAddress = dbManager.executeQuery(AddressQueries.SELECT_ADDRESS_BY_ID, locationId);

        if (rsAddress.next()) {
            address.setId(locationId);
            address.setNum(rsAddress.getInt("num"));
            address.setStreet(rsAddress.getString("street"));
            address.setCity(rsAddress.getString("city"));
        } else {
            // Handle the case where no address is found
            throw new SQLException("No address found for location_id: " + locationId);
        }

        supermarket.setLocation(address);
        return supermarket;
    }

    @Override
    public List<Supermarket> getSorted(String sortBy, String sortOrder) throws SQLException {
        String query = String.format(SupermarketQueries.GET_SORTED_SUPERMARKETS, sortBy, sortOrder);
        ResultSet rs = dbManager.executeQuery(query);
        List<Supermarket> supermarkets = new ArrayList<>();
        while (rs.next()) {
            supermarkets.add(extractSupermarketFromResultSet(rs));
        }
        return supermarkets;
    }

    public List<Customer> getCustomersBySupermarket(int supermarketId) throws SQLException{
        return null;
    }

//   TODO: @Override
//   public List<Customer> getCustomersBySupermarket(int supermarketId) throws SQLException {
//       ResultSet rs = dbManager.executeQuery(SupermarketQueries.GET_CUSTOMERS_BY_SUPERMARKET, supermarketId);
//       List<Customer> customers = new ArrayList<>();
//       while (rs.next()) {
//           customers.add(extractCustomerFromResultSet(rs));
//       }
//       return customers;
//    }

    @Override
    public void addCustomerToSupermarket(int customerId, int supermarketId) throws SQLException {
        dbManager.executeUpdate(SupermarketQueries.ADD_CUSTOMER_TO_SUPERMARKET, customerId, supermarketId);
    }

    @Override
    public void removeCustomerFromSupermarket(int customerId, int supermarketId) throws SQLException {
        dbManager.executeUpdate(SupermarketQueries.REMOVE_CUSTOMER_FROM_SUPERMARKET, customerId, supermarketId);
    }

    @Override
    public List<Supermarket> getByIds(List<Integer> ids) throws SQLException {
        String placeholders = String.join(",", Collections.nCopies(ids.size(), "?"));
        String query = String.format(SupermarketQueries.GET_SUPERMARKETS_BY_IDS, placeholders);
        ResultSet rs = dbManager.executeQuery(query, ids.toArray());
        List<Supermarket> supermarkets = new ArrayList<>();
        while (rs.next()) {
            supermarkets.add(extractSupermarketFromResultSet(rs));
        }
        return supermarkets;
    }

//    private Customer extractCustomerFromResultSet(ResultSet rs) throws SQLException {
//        Customer customer = new Customer();
//        customer.setId(rs.getInt("id"));
//        customer.setName(rs.getString("name"));
//        // Set other customer properties as needed
//        return customer;
//    }
}
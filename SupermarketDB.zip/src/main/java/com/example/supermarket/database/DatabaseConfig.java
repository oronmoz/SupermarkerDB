package com.example.supermarket.database;

public class DatabaseConfig {
    public static final String URL = "jdbc:postgresql://localhost:5432/supermarket";
    public static final String USER = "postgres";
    public static final String PASSWORD = "1234";
    public static final String DRIVER = "org.postgresql.Driver";
}
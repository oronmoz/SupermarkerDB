package com.example.supermarket.controllers;

import com.example.supermarket.components.AdvancedSearchBar;
import com.example.supermarket.models.*;
import com.example.supermarket.services.*;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.collections.FXCollections;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import static java.lang.Float.parseFloat;


public class ShoppingSessionController implements Initializable {

    @FXML private TabPane wizardTabPane;
    @FXML private ComboBox<Customer> customerComboBox;
    @FXML private ComboBox<Supermarket> supermarketComboBox;
    @FXML private ComboBox<Product> productComboBox; ;
    @FXML private AdvancedSearchBar productSearchBar;
    @FXML private TableView<Product> productTable;
    @FXML private TableView<ShoppingItem> cartTable;
    @FXML private TableView<ShoppingItem> orderSummaryTable;
    @FXML private Label totalLabel;

    private CustomerService customerService;
    private SupermarketService supermarketService;
    private ProductService productService;
    private ShoppingCartService shoppingCartService;
    private ShoppingCart currentCart;
    private List<ShoppingCart> activeCarts = new ArrayList<>();


    public ShoppingSessionController() {

    }

    public void initServices(SupermarketService supermarketService, ProductService productService,
                             CustomerService customerService, ShoppingCartService shoppingCartService) {
        this.supermarketService = supermarketService;
        this.productService = productService;
        this.customerService = customerService;
        this.shoppingCartService = shoppingCartService;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setupProductSearchBar();
        setupProductTable();
        setupCartTable();
        setupOrderSummaryTable();
    }

    public void refreshShoppingWizard() {
        try {
            setupCustomerComboBox();
            setupSupermarketComboBox();
            setupProductComboBox();
            loadProducts();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error refreshing shopping wizard: " + e.getMessage());
        }
    }

    private void setupCustomerComboBox() throws SQLException {
        customerComboBox.setItems(FXCollections.observableArrayList(customerService.getAll()));
    }

    private void setupSupermarketComboBox() throws SQLException {
        supermarketComboBox.setItems(FXCollections.observableArrayList(supermarketService.getAllSupermarkets()));
    }

    private void setupProductComboBox() throws SQLException {
        productComboBox.setItems(FXCollections.observableArrayList(productService.getAllProducts()));
    }


    private void setupProductSearchBar() {
        String[] searchCriteria = {"Name", "Barcode", "Type"};
        productSearchBar = new AdvancedSearchBar(searchCriteria, this::searchProducts);
    }

    public ShoppingCart getCurrentCart() {
        return currentCart;
    }

    private void setupProductTable() {
        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));

        TableColumn<Product, String> barcodeColumn = new TableColumn<>("Barcode");
        barcodeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getBarcode()));

        TableColumn<Product, String> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.format("%.2f", cellData.getValue().getPrice())));

        productTable.getColumns().addAll(nameColumn, barcodeColumn, priceColumn);
    }

    private void setupCartTable() {
        TableColumn<ShoppingItem, String> productNameColumn = new TableColumn<>("Product");
        productNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getProductName()));

        TableColumn<ShoppingItem, Number> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getQuantity()));

        TableColumn<ShoppingItem, Number> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(cellData -> new SimpleFloatProperty(cellData.getValue().getPrice()));

        cartTable.getColumns().addAll(productNameColumn, quantityColumn, priceColumn);
    }

    private void setupOrderSummaryTable() {
        // Similar to cartTable setup
        TableColumn<ShoppingItem, String> productNameColumn = new TableColumn<>("Product");
        productNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getProductName()));

        TableColumn<ShoppingItem, Number> quantityColumn = new TableColumn<>("Quantity");
        quantityColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getQuantity()));

        TableColumn<ShoppingItem, Number> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(cellData -> new SimpleFloatProperty(cellData.getValue().getPrice()));

        orderSummaryTable.getColumns().addAll(productNameColumn, quantityColumn, priceColumn);
    }

    @FXML
    public void startShopping() {
        Customer selectedCustomer = customerComboBox.getValue();
        Supermarket selectedSupermarket = supermarketComboBox.getValue();
        if (selectedCustomer != null && selectedSupermarket != null) {
            try {
                currentCart = shoppingCartService.createShoppingCart(selectedCustomer.getId(), selectedSupermarket.getId());
                activeCarts.add(currentCart);
                loadProducts();
                wizardTabPane.getSelectionModel().select(2); // Move to product selection tab
            } catch (SQLException e) {
                showAlert("Error starting new session: " + e.getMessage());
            }
        } else {
            showAlert("Please select a customer and a supermarket");
        }
    }

    private void loadProducts() throws SQLException {
        productTable.setItems(FXCollections.observableArrayList(
                productService.getProductsBySupermarket(supermarketComboBox.getValue().getId())
        ));
    }

    private void searchProducts(String searchCriteria) {
        String[] parts = searchCriteria.split(":");
        String criteria = parts[0];
        String term = parts[1].toLowerCase();

        try {
            List<Product> allProducts = productService.getProductsBySupermarket(supermarketComboBox.getValue().getId());
            List<Product> filteredProducts = allProducts.stream()
                    .filter(product -> {
                        switch (criteria) {
                            case "Name":
                                return product.getName().toLowerCase().contains(term);
                            case "Barcode":
                                return product.getBarcode().toLowerCase().contains(term);
                            case "Type":
                                return product.getType().toString().toLowerCase().contains(term);
                            default:
                                return false;
                        }
                    })
                    .collect(Collectors.toList());
            productTable.setItems(FXCollections.observableArrayList(filteredProducts));
        } catch (SQLException e) {
            showAlert("Error searching products: " + e.getMessage());
        }
    }

    @FXML
    private void addToCart() {
        Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            int quantity = showQuantityDialog();
            if (quantity > 0) {
                try {
                    ShoppingItem item = new ShoppingItem(0, currentCart.getId(), selectedProduct.getBarcode(),
                            selectedProduct.getName(), parseFloat(selectedProduct.getPrice()), quantity);
                    shoppingCartService.addItemToCart(currentCart, item);
                    currentCart.addItem(item);
                    updateCartTable();
                } catch (SQLException e) {
                    showAlert("Error adding item to cart: " + e.getMessage());
                }
            }
        } else {
            showAlert("Please select a product");
        }
    }

    private void updateCartTable() {
        cartTable.setItems(FXCollections.observableArrayList(currentCart.getItems()));
        updateTotal();
    }

    private void updateTotal() {
        double total = currentCart.getTotalPrice();
        totalLabel.setText(String.format("Total: $%.2f", total));
    }

    @FXML
    private void proceedToCheckout() {
        if (!currentCart.getItems().isEmpty()) {
            wizardTabPane.getSelectionModel().select(3);
            orderSummaryTable.setItems(FXCollections.observableArrayList(currentCart.getItems()));
            updateTotal();
        } else {
            showAlert("Your cart is empty");
        }
    }

    @FXML
    private void checkout() {
        if (currentCart != null && !currentCart.getItems().isEmpty()) {
            try {
                shoppingCartService.checkout(currentCart.getCustomerId(), currentCart.getSupermarketId());
                showAlert("Checkout Complete");
                activeCarts.remove(currentCart);
                resetShoppingSession();
            } catch (SQLException e) {
                showAlert("Error during checkout: " + e.getMessage());
            }
        } else {
            showAlert("Cannot checkout: Cart is empty");
        }
    }

    public void resetShoppingSession() {
        currentCart = null;
        customerComboBox.setValue(null);
        supermarketComboBox.setValue(null);
        productComboBox.setValue(null);
        cartTable.getItems().clear();
        orderSummaryTable.getItems().clear();
        totalLabel.setText("Total: $0.00");
        wizardTabPane.getSelectionModel().select(0);
    }

    private int showQuantityDialog() {
        TextInputDialog dialog = new TextInputDialog("1");
        dialog.setTitle("Enter Quantity");
        dialog.setHeaderText("Enter the quantity for the selected product");
        dialog.setContentText("Quantity:");

        return dialog.showAndWait()
                .map(Integer::parseInt)
                .orElse(0);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Shopping Session");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public List<ShoppingCart> getActiveCarts() {
        return new ArrayList<>(activeCarts);
    }

//    @FXML
//    public void startShopping(ShoppingCart cart) {
//        Customer selectedCustomer = customerComboBox.getValue();
//        Supermarket selectedSupermarket = supermarketComboBox.getValue();
//        if (selectedCustomer != null && selectedSupermarket != null) {
//            try {
//                currentCart = shoppingSessionManager.startNewSession(selectedCustomer, selectedSupermarket);
//                loadProducts();
//                wizardTabPane.getSelectionModel().select(2); // Move to product selection tab
//            } catch (SQLException e) {
//                showAlert("Error");
//            }
//        } else {
//            showAlert("Invalid Selection");
//        }
//    }

    @FXML
    private void nextToSupermarketSelection() {
        if (customerComboBox.getValue() != null) {
            wizardTabPane.getSelectionModel().select(1);
        } else {
            showAlert("Please select a customer");
        }
    }

    @FXML
    private void nextToProductSelection() throws SQLException {
        if (supermarketComboBox.getValue() != null) {
            wizardTabPane.getSelectionModel().select(2);
            currentCart = shoppingCartService.createShoppingCart(customerComboBox.getValue().getId(), supermarketComboBox.getValue().getId());
            loadProducts();
        } else {
            showAlert("Please select a supermarket");
        }
    }

    private void resetWizard() {
        customerComboBox.setValue(null);
        supermarketComboBox.setValue(null);
        currentCart = null;
        cartTable.getItems().clear();
        orderSummaryTable.getItems().clear();
        totalLabel.setText("Total: $0.00");
        wizardTabPane.getSelectionModel().select(0);
    }

    @FXML
    private void viewCart() {
        if (currentCart != null) {
            updateCartTable();
            wizardTabPane.getSelectionModel().select(3); // Move to cart view tab
        } else {
            showAlert("No Active Cart");
        }
    }

    @FXML
    private void completePurchase() {
        // Implementation for completing the purchase
        System.out.println("Completing purchase...");
    }
}
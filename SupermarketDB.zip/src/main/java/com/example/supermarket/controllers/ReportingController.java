package com.example.supermarket.controllers;
import com.example.supermarket.components.ReportSelectionTreeView;
import com.example.supermarket.models.*;
import com.example.supermarket.services.CustomerService;
import com.example.supermarket.services.ProductService;
import com.example.supermarket.services.ShoppingCartService;
import com.example.supermarket.services.SupermarketService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class ReportingController implements Initializable {
    @FXML private VBox reportSelectionContainer;
    @FXML private TreeView<String> reportSelectionTree;
    @FXML private StackPane reportContentArea;
    @FXML private SupermarketService supermarketService;
    @FXML private ShoppingCartService shoppingCartService;
    @FXML private CustomerService customerService;
    @FXML private ProductService productService;


    public ReportingController(){
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ReportSelectionTreeView reportTree = new ReportSelectionTreeView(this::handleReportSelection);
        reportSelectionContainer.getChildren().add(reportTree);
    }

    public void initServices(SupermarketService supermarketService, ProductService productService,
                             CustomerService customerService, ShoppingCartService shoppingCartService) {
        this.supermarketService = supermarketService;
        this.productService = productService;
        this.customerService = customerService;
        this.shoppingCartService = shoppingCartService;
        refreshReporter();
    }

    public void refreshReporter(){

    }

    private void setupReportSelectionTree() {
        TreeItem<String> rootItem = new TreeItem<>("Reports");

        TreeItem<String> salesReports = new TreeItem<>("Sales Reports");
        salesReports.getChildren().addAll(
                new TreeItem<>("Daily Sales"),
                new TreeItem<>("Monthly Sales"),
                new TreeItem<>("Annual Sales")
        );

        TreeItem<String> inventoryReports = new TreeItem<>("Inventory Reports");
        inventoryReports.getChildren().addAll(
                new TreeItem<>("Current Stock"),
                new TreeItem<>("Low Stock Alert")
        );

        TreeItem<String> customerReports = new TreeItem<>("Customer Reports");
        customerReports.getChildren().addAll(
                new TreeItem<>("Top Customers"),
                new TreeItem<>("Customer Spending Analysis")
        );

        rootItem.getChildren().addAll(salesReports, inventoryReports, customerReports);
        reportSelectionTree.setRoot(rootItem);

        reportSelectionTree.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && newValue.isLeaf()) {
                loadReport(newValue.getValue());
            }
        });
    }

    private void loadReport(String reportName) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/supermarket/views/reports/" + reportName.replace(" ", "") + ".fxml"));
            reportContentArea.getChildren().setAll((javafx.scene.Node) loader.load());
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    @FXML
    private void generateReport() {
        String selectedReport = reportSelectionTree.getSelectionModel().getSelectedItem().getValue();
        handleReportSelection(selectedReport);
    }

    private void handleReportSelection(String reportType) {
        switch (reportType) {
            case "Daily Sales":
                generateSalesReport();
                break;
            case "Monthly Sales":
                generateSalesReport();
                break;
            case "Annual Sales":
                generateSalesReport();
                break;
            case "Inventory Report":
                generateInventoryReport();
                break;
            case "Customer Report":
                generateCustomerReport();
                break;
            case "Supplier Report":
                //TODO: generateSupplierReport();
                break;
            case "Supermarket Performance":
                generateSupermarketPerformanceReport();
                break;
            default:
                System.out.println("Unknown report type: " + reportType);
        }
    }

    private void generateSalesReport() {
        try {
            List<ShoppingCart> purchases = shoppingCartService.getAll();
            Chart salesChart = generateSalesChart(purchases);
            showChartDialog("Sales Report", salesChart);
        } catch (SQLException e) {
            showAlert("Error generating sales report: " + e.getMessage());
        }
    }

    private void generateInventoryReport() {
        try {
            List<Product> products = productService.getAllProducts();
            Chart inventoryChart = generateInventoryChart(products);
            showChartDialog("Inventory Report", inventoryChart);
        } catch (SQLException e) {
            showAlert("Error generating inventory report: " + e.getMessage());
        }
    }

    private void generateCustomerReport() {
        try {
            List<Customer> customers = customerService.getAll();
            Chart customerChart = generateCustomerChart(customers);
            showChartDialog("Customer Report", customerChart);
        } catch (SQLException e) {
            showAlert("Error generating customer report: " + e.getMessage());
        }
    }

    @FXML
    private void exportToPDF() {
        Chart chart = (Chart) reportContentArea.getChildren().get(0);
        String reportTitle = reportSelectionTree.getSelectionModel().getSelectedItem().getValue();
        exportReportToPDF(reportTitle, chart);
    }

    @FXML
    private void exportToCSV() {
        String reportTitle = reportSelectionTree.getSelectionModel().getSelectedItem().getValue();
        exportReportToCSV(reportTitle);
    }

    //TODO:
//    private void generateSupplierReport() {
//        try {
//            List<Supplier> suppliers = productService.getAllSuppliers();
//            Chart supplierChart = generateSupplierChart(suppliers);
//            showChartDialog("Supplier Report", supplierChart);
//        } catch (SQLException e) {
//            showAlert("Error generating supplier report: " + e.getMessage());
//        }
//    }

    private void generateSupermarketPerformanceReport() {
        try {
            List<Supermarket> supermarkets = supermarketService.getAllSupermarkets();
            Chart performanceChart = generateSupermarketPerformanceChart(supermarkets);
            showChartDialog("Supermarket Performance Report", performanceChart);
        } catch (SQLException e) {
            showAlert("Error generating supermarket performance report: " + e.getMessage());
        }
    }

    private Chart generateSalesChart(List<ShoppingCart> purchases) {
        BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        chart.setTitle("Sales Report");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Sales");

        Map<LocalDate, Double> salesByDate = purchases.stream()
                .collect(Collectors.groupingBy(
                        cart -> cart.getCreatedAt().toLocalDate(),
                        Collectors.summingDouble(ShoppingCart::getTotalPrice)
                ));

        salesByDate.forEach((date, total) ->
                series.getData().add(new XYChart.Data<>(date.toString(), total)));

        chart.getData().add(series);
        return chart;
    }

    private Chart generateInventoryChart(List<Product> products) {
        PieChart chart = new PieChart();
        chart.setTitle("Inventory Report");

        Map<Product.ProductType, Long> productCounts = products.stream()
                .collect(Collectors.groupingBy(Product::getType, Collectors.counting()));

        productCounts.forEach((type, count) ->
                chart.getData().add(new PieChart.Data(type.toString(), count)));

        return chart;
    }

    private Chart generateCustomerChart(List<Customer> customers) {
        BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        chart.setTitle("Customer Report");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Spend");

        customers.stream()
                .sorted(Comparator.comparing(this::getCustomerTotalSpend).reversed())
                .limit(10)
                .forEach(customer -> series.getData().add(
                        new XYChart.Data<>(customer.getName(), getCustomerTotalSpend(customer))
                ));

        chart.getData().add(series);
        return chart;
    }


    private Chart generateSupplierChart(List<Supplier> suppliers) {
        // Assuming Supplier class exists and has relevant methods
        BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        chart.setTitle("Supplier Report");

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Products Supplied");

        suppliers.forEach(supplier -> series.getData().add(
                new XYChart.Data<>(supplier.getName(), supplier.getSuppliedProducts().size())
        ));

        chart.getData().add(series);
        return chart;
    }


    private void showChartDialog(String title, Chart chart) {
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setHeaderText(title);

        VBox content = new VBox(10, chart);
        dialog.getDialogPane().setContent(content);

        ButtonType exportPdfButton = new ButtonType("Export to PDF", ButtonBar.ButtonData.LEFT);
        ButtonType exportCsvButton = new ButtonType("Export to CSV", ButtonBar.ButtonData.LEFT);
        ButtonType closeButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(exportPdfButton, exportCsvButton, closeButton);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == exportPdfButton) {
                exportReportToPDF(title, chart);
            } else if (dialogButton == exportCsvButton) {
                exportReportToCSV(title);
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void exportReportToPDF(String title, Chart chart) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save PDF Report");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try {
                // Implement PDF export logic here
                showAlert("Report exported to PDF successfully");
            } catch (Exception e) {
                showAlert("Error exporting report to PDF: " + e.getMessage());
            }
        }
    }

    private void exportReportToCSV(String title) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save CSV Report");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try {
                List<?> data = getReportData(title);
                // Implement CSV export logic here
                showAlert("Report exported to CSV successfully");
            } catch (SQLException e) {
                showAlert("Error exporting report to CSV: " + e.getMessage());
            }
        }
    }

    private List<?> getReportData(String title) throws SQLException {
        switch (title) {
            case "Sales Report":
                return shoppingCartService.getAll();
            case "Inventory Report":
                return productService.getAllProducts();
            case "Customer Report":
                return customerService.getAll();
//        TODO    case "Supplier Report":
//                return productService.getAllSuppliers;
            case "Supermarket Performance Report":
                return supermarketService.getAllSupermarkets();
            default:
                throw new IllegalArgumentException("Unknown report type: " + title);
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Report Generation");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void generateDailySalesReport() {
        try {
            LocalDate today = LocalDate.now();
            List<ShoppingCart> todaysPurchases = shoppingCartService.getAll().stream()
                    .filter(cart -> cart.getCreatedAt().toLocalDate().equals(today))
                    .collect(Collectors.toList());
            Chart chart = generateSalesChart(todaysPurchases);
            showChartDialog("Daily Sales Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating daily sales report: " + e.getMessage());
        }
    }

    private void generateMonthlySalesReport() {
        try {
            LocalDate startOfMonth = LocalDate.now().withDayOfMonth(1);
            List<ShoppingCart> monthlyPurchases = shoppingCartService.getAll().stream()
                    .filter(cart -> cart.getCreatedAt().toLocalDate().isAfter(startOfMonth.minusDays(1)))
                    .collect(Collectors.toList());
            Chart chart = generateSalesChart(monthlyPurchases);
            showChartDialog("Monthly Sales Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating monthly sales report: " + e.getMessage());
        }
    }

    private void generateAnnualSalesReport() {
        try {
            LocalDate startOfYear = LocalDate.now().withDayOfYear(1);
            List<ShoppingCart> yearlyPurchases = shoppingCartService.getAll().stream()
                    .filter(cart -> cart.getCreatedAt().toLocalDate().isAfter(startOfYear.minusDays(1)))
                    .collect(Collectors.toList());
            Chart chart = generateSalesChart(yearlyPurchases);
            showChartDialog("Annual Sales Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating annual sales report: " + e.getMessage());
        }
    }

//    private void generateLowStockAlert() {
//        try {
//            List<Product> lowStockProducts = productService.getAllProducts().stream()
//                    .filter(product -> product.getCount() < 10) // Assuming 10 is the low stock threshold
//                    .collect(Collectors.toList());
//            Chart chart = generateInventoryChart(lowStockProducts);
//            showChartDialog("Low Stock Alert", chart);
//        } catch (SQLException e) {
//            showAlert("Error generating low stock alert: " + e.getMessage());
//        }
//    }

    private void generateProductPerformanceReport() {
        try {
            List<Product> allProducts = productService.getAllProducts();
            List<ShoppingCart> allPurchases = shoppingCartService.getAll();

            Map<String, Long> productSales = allPurchases.stream()
                    .flatMap(cart -> cart.getItems().stream())
                    .collect(Collectors.groupingBy(ShoppingItem::getBarcode, Collectors.summingLong(ShoppingItem::getQuantity)));

            BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
            chart.setTitle("Product Performance Report");

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Sales Count");

            allProducts.forEach(product -> series.getData().add(
                    new XYChart.Data<>(product.getName(), productSales.getOrDefault(product.getBarcode(), 0L))
            ));

            chart.getData().add(series);
            showChartDialog("Product Performance Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating product performance report: " + e.getMessage());
        }
    }

    private void generateTopCustomersReport() {
        try {
            List<Customer> allCustomers = customerService.getAll();
            List<Customer> topCustomers = allCustomers.stream()
                    .sorted(Comparator.comparing(this::getCustomerTotalSpend).reversed())
                    .limit(10)
                    .collect(Collectors.toList());
            Chart chart = generateCustomerChart(topCustomers);
            showChartDialog("Top Customers Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating top customers report: " + e.getMessage());
        }
    }

    private void generateCustomerShoppingPatternsReport() {
        try {
            List<Customer> allCustomers = customerService.getAll();
            List<ShoppingCart> allPurchases = shoppingCartService.getAll();

            Map<Integer, List<ShoppingCart>> purchasesByCustomer = allPurchases.stream()
                    .collect(Collectors.groupingBy(ShoppingCart::getCustomerId));

            BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
            chart.setTitle("Customer Shopping Patterns Report");

            XYChart.Series<String, Number> frequencySeries = new XYChart.Series<>();
            frequencySeries.setName("Shopping Frequency");

            XYChart.Series<String, Number> averageSpendSeries = new XYChart.Series<>();
            averageSpendSeries.setName("Average Spend");

            allCustomers.forEach(customer -> {
                List<ShoppingCart> customerPurchases = purchasesByCustomer.getOrDefault(customer.getId(), Collections.emptyList());
                frequencySeries.getData().add(new XYChart.Data<>(customer.getName(), customerPurchases.size()));
                double averageSpend = customerPurchases.stream().mapToDouble(ShoppingCart::getTotalPrice).average().orElse(0);
                averageSpendSeries.getData().add(new XYChart.Data<>(customer.getName(), averageSpend));
            });

            chart.getData().addAll(frequencySeries, averageSpendSeries);
            showChartDialog("Customer Shopping Patterns Report", chart);
        } catch (SQLException e) {
            showAlert("Error generating customer shopping patterns report: " + e.getMessage());
        }
    }

    private Chart generateSupermarketPerformanceChart(List<Supermarket> supermarkets) {
        BarChart<String, Number> chart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        chart.setTitle("Supermarket Performance Report");

        XYChart.Series<String, Number> salesSeries = new XYChart.Series<>();
        salesSeries.setName("Total Sales");

        XYChart.Series<String, Number> customerSeries = new XYChart.Series<>();
        customerSeries.setName("Customer Count");

        supermarkets.forEach(supermarket -> {
            salesSeries.getData().add(new XYChart.Data<>(supermarket.getName(), getSupermarketTotalSales(supermarket)));
            customerSeries.getData().add(new XYChart.Data<>(supermarket.getName(), getSupermarketCustomerCount(supermarket)));
        });

        chart.getData().addAll(salesSeries, customerSeries);
        return chart;
    }

    private double getCustomerTotalSpend(Customer customer) {
        try {
            return customerService.getTotalSpend(customer.getId());
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private double getSupermarketTotalSales(Supermarket supermarket) {
        try {
            List<ShoppingCart> supermarketPurchases = shoppingCartService.getShoppingCartsBySupermarketId(supermarket.getId());
            return supermarketPurchases.stream().mapToDouble(ShoppingCart::getTotalPrice).sum();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private int getSupermarketCustomerCount(Supermarket supermarket) {
        try {
            return customerService.getBySupermarket(supermarket.getId()).size();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
package com.example;

import javafx.application.Application;
import com.example.supermarket.SupermarketApp;

public class Main {
    public static void main(String[] args) {
        Application.launch(SupermarketApp.class, args);
    }
}